<?php
include 'function.php';

if (!empty($_GET['idVente']) && !empty($_GET['idArticle']) && !empty($_GET['quantite'])) {
    // Mettre à jour l'état de la vente
    $sql = "UPDATE vente SET etat = ? WHERE id = ?";
    $req = $GLOBALS['connexion']->prepare($sql);
    $req->execute(array(0, $_GET['idVente']));
    
    if ($req->rowCount() != 0) {
        // Mettre à jour la quantité d'articles
        $sql = "UPDATE article SET quantite = quantite + ? WHERE id = ?";
        $req = $GLOBALS['connexion']->prepare($sql);
        $req->execute(array($_GET['quantite'], $_GET['idArticle']));
    }

    if ($req->rowCount()!= 0) {
        $_SESSION['message']['text'] = "Vente anuuler avec succés " ;
        $_SESSION['message']['type'] = "success" ;
    } else {
        $_SESSION['message']['text'] = "impossible de faire cette annulation de cette vente" ;
        $_SESSION['message']['type'] = "danger" ;   
    }
}

header('location: vente.php');
?>
