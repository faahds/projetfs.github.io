<?php 
session_start();

$nom_serveur = "localhost:81";
$nom_base_de_donne = "gestion_stock";
$utilisateur = "root";
$mot_pass = "";


try {  
    $connexion = new PDO("mysql:host$nom_serveur;dbname=$nom_base_de_donne",$utilisateur,$mot_pass);
    $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $connexion->exec("USE $nom_base_de_donne");

    return $connexion;
}   catch (PDOException $e) {
    die("Erreur de connexion : ".$e->getMessage());

}


