<?php
include 'connexion.php';
include 'function.php';
            if (
            !empty($_POST['id_article'])
            && !empty($_POST['id_client'])
            && !empty($_POST['quantite'])
            && !empty($_POST['prix'])
            ){
            $article = getArticle($_POST['id_article']);
            if (!empty($article) && is_array($article)) {
            if ($_POST['quantite']>$article['quantite']) {
            $_SESSION['message']['text'] = "La quantite a vendre n'est pas disponible" ;
            $_SESSION['message']['type'] = "danger" ;  
            }else{
            $sql = "INSERT INTO `$nom_base_de_donne`.`vente` (id_article, id_client, quantite, prix)
            VALUES (?, ?, ?, ?)";
      
            $req =  $connexion->prepare($sql); 
            $req->execute(array(
               $_POST['id_article'],
               $_POST['id_client'],
               $_POST['quantite'], 
               $_POST['prix']
            ));
            if ($req->rowCount()!=0) {
            $nouvelle_quantite = $article['quantite'] - $_POST['quantite'];
            $sql = "UPDATE article SET quantite=? WHERE id=?";
            $req = $connexion->prepare($sql); 
            $req->execute(array(
            $nouvelle_quantite,
            $_POST['id_article'],
            ));
            if ($req->rowCount()!= 0) {
                $_SESSION['message']['text'] = "Votre vente effectué avec succés " ;
                $_SESSION['message']['type'] = "success" ;
            } else {
                $_SESSION['message']['text'] = "impossible de faire cette vente" ;
                $_SESSION['message']['type'] = "danger" ;   
            }
      
            } else {
            $_SESSION['message']['text'] = "une erreur s'est produite lors de la vente " ;
            $_SESSION['message']['type'] = "danger" ;     
            }
            }
            }

            } else {
            $_SESSION['message']['text'] = "une information obligatoire non rensignée" ;
            $_SESSION['message']['type'] = "danger" ; 
            }
            header('location: vente.php');
