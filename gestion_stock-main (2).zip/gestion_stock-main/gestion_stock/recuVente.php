<?php 
include 'entete.php';

// Initialize $vente to null
$vente = null;

// Check if ID is provided in the URL
if (!empty($_GET['id'])) {
    // Fetch sale information based on ID
    $vente = getVente($_GET['id']);
}

?>
<link rel="stylesheet" href="f.css">
<div class="home-content"> 

    <div style="text-align: center;"> <!-- Div pour centrer le bouton -->
        <button onclick="imprimerPage()">Imprimer</button>
    </div>

<script>
    // Fonction pour imprimer la page
    function imprimerPage() {
        window.print();
    }
</script>

    <div class="page">
        <div class="cote-a-cote">
        <h2><img src="phhh-removebg-preview.png" alt=""></h2>

            <div>
                <p>Recu N° #: <?= $vente['id'] ?> </p>
                <p>Date: <?= date('d/m/Y H:i:s', strtotime($vente['date_vente'])) ?> </p>
            </div>
        </div>

        <div class="cote-a-cote">
            <p>nom :  <?= $vente['nom']." " . $vente['prenom'] ?> </p>
        </div>

        <p>Téléphone :  <?= $vente['telephone']?> </p>
        <p>Adresse : <?= $vente['adresse']?>  </p>
       <br><br><br><br><br>
        <table class="mtable">
            <tr>
                <th>désignation</th>
                <th>Quantite</th>
                <th>Prix_Unitaire</th>
                <th>Date</th>
            </tr>
            <?php
            // Fetch all sales if $vente is empty
            // or display the sale details if $vente is not empty
            $ventes = $vente ? array($vente) : getVente();
            
            if (!empty($ventes) && is_array($ventes)) {
                foreach ($ventes as $key => $value) {
            ?>
                    <tr>
                        <td><?= $value['nom_article'] ?></td>
                        <td><?= $value['quantite'] ?></td>
                        <td><?= $value['prix'] ?></td>
                        <td><?= date('d/m/Y H:i:s', strtotime($value['date_vente'])) ?></td>
                    </tr>
            <?php
                }
            }
            ?>
        </table>
    </div>
</div>
</section>
<?php
include 'pied.php.';
?>
<script>
    function setPrix() {
        var article = document.querySelector('#id_article');
        var quantite = document.querySelector('#quantite');
        var prix = document.querySelector('#prix');

        // Vérifier si un article est sélectionné
        if (article && article.selectedIndex !== -1) {
            // Obtenir le prix unitaire depuis l'attribut data-prix de l'option sélectionnée
            var prixUnitaire = parseFloat(article.options[article.selectedIndex].getAttribute('data-prix'));
            // Vérifier si la quantité est un nombre valide
            var quantiteValue = parseFloat(quantite.value);
            if (!isNaN(quantiteValue) && quantiteValue >= 0) {
                // Calculer et afficher le prix total
                prix.value = (prixUnitaire * quantiteValue).toFixed(2);
            } else {
                // Afficher un message d'erreur si la quantité n'est pas valide
                prix.value = "Quantité invalide";
            }
        } else {
            // Afficher un message d'erreur si aucun article n'est sélectionné
            prix.value = "Sélectionnez un article";
        }
    }
</script>
