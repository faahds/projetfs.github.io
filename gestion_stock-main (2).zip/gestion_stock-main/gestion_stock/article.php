<?php 
include 'entete.php' ;
if (!empty($_GET['id'])) {
$article = getArticle($_GET['id']);
}
?>
    <div class="home-content"> 
    <div class="overview-boxes">
    <div class ="box">
    <form action="<?= !empty($_GET['id']) ? "modifArticle.php" : "Ajoutearticle.php" ?> " method="post">

    <label for="nom_article">Nom de l'article</label>
    <input value="<?= !empty($_GET['id']) ? $article['nom_article'] : "" ?>" type="text" name="nom_article" id="nom_article" placeholder=" Veuillez saisir le nom">
    <input value="<?= !empty($_GET['id']) ? $article['id'] : "" ?>" type="hidden" name="id" id="id">


    <label for="categorie">categorie</label>
    <select name="categorie" id="categorie">
     <option <?= !empty($_GET['id']) && $article['categorie']== "RHYMATO" ? "selected" : "" ?> value="RHYMATO">RHYMATO</option>   
     <option <?= !empty($_GET['id']) && $article['categorie']== "MEDCIN SPORT" ? "selected" : "" ?> value="MEDCIN SPORT">MEDCIN SPORT</option>   
     <option <?= !empty($_GET['id']) && $article['categorie']== "COSEMETIQUE" ? "selected" : "" ?> value="COSEMETIQUE">COSEMETIQUE </option>   
     <option <?= !empty($_GET['id']) && $article['categorie']== "HYGENE BUCO-DENTAIRE" ? "selected" : "" ?> value="HYGENE BUCO-DENTAIRE">HYGENE BUCO-DENTAIRE</option>   
     <option <?= !empty($_GET['id']) && $article['categorie']== "SOIN & HYGIENE POUR BEBE" ? "selected" : "" ?> value="SOIN & HYGIENE POUR BEBE">SOIN & HYGIENE POUR BEBE</option>   
    </select>

    <label for="quantite">Quantité</label>
    <input value="<?= !empty($_GET['id']) ? $article['quantite'] : "" ?>" type="text" name="quantite" id="quantite" placeholder=" Veuillez saisir la quantite">

    <label for="prix_unitaire">Prix_unitaire</label>
    <input value="<?= !empty($_GET['id']) ? $article['prix_unitaire'] : "" ?>" type="text" name="prix_unitaire" id="prix_unitaire" placeholder=" Veuillez saisir le prix">

    <label for="date_fabrication">Date de fabrication </label>
    <input value="<?= !empty($_GET['id']) ? $article['date_fabrication'] : "" ?>" type="datetime-local" name="date_fabrication" id="date_fabrication" placeholder=" Veuillez saisir la date">

    <label for="date_expiration">Date fin promotion</label>
    <input value="<?= !empty($_GET['id']) ? $article['date_expiration'] : "" ?>" type="datetime-local" name="date_expiration" id="date_expiration" placeholder=" Veuillez saisir la date">

    <button type="submit">valider</button>

    <?php
    if (!empty($_SESSION['message']['text'])) {
    ?>
       <div class="alert <?= $_SESSION ['message']['type']?>">
        <?= $_SESSION['message']['text']?>
        </div>
    <?php   
    } 
    ?>
    </form>
    </div>

    <div class="box">
    <table class="mtable">
        <tr>
            <th>Nom article</th>
            <th>Categorie</th>
            <th>Quantite</th>
            <th>Prix unitaire</th>
            <th>Date fabrication</th>
            <th>Date d'expiration</th>
            <th>Action</th>
        </tr>

        <?php
        $articles = getArticle();
        if (!empty($articles) && is_array($articles)) {
            foreach ($articles as $key => $value) {
            ?>
            <tr>
            <td><?= $value['nom_article']?></td>
            <td><?= $value['categorie']?></td>
            <td><?= $value['quantite']?></td>
            <td><?= $value['prix_unitaire']?></td>
            <td><?= date('d/m/Y H:i:s', strtotime($value['date_fabrication']))?></td>
            <td><?= date('d/m/Y H:i:s', strtotime($value['date_expiration']))?></td>



            <td><a href="?id= <?= $value['id']?>"><i class='bx bx-edit-alt'></i></a></td>

            </tr>
            <?php
            }
        }
        ?>

    </table>
    </div>
    </div>
    </div>
    </section>
<?php
include 'pied.php.' 
?>
