<?php
include 'connexion.php';


function getArticle($id=null)
{
if (!empty($id)) {
    $sql = "SELECT * FROM article WHERE id=?";
            
    $req = $GLOBALS['connexion']->prepare($sql);
        
    $req->execute(array($id));

    return $req->fetch();


  } else {

        $sql = "SELECT * FROM article";
            
        $req = $GLOBALS['connexion']->prepare($sql);
            
        $req->execute();
    
        return $req->fetchAll();
   

   } 
     
}

function getClient($id=null)
{
if (!empty($id)) {
    $sql = "SELECT * FROM client WHERE id=?";
            
    $req = $GLOBALS['connexion']->prepare($sql);
        
    $req->execute(array($id));

    return $req->fetch();


  } else {

        $sql = "SELECT * FROM client";
            
        $req = $GLOBALS['connexion']->prepare($sql);
            
        $req->execute();
    
        return $req->fetchAll();
   

   } 
     
}

function getVente($id = null) {
    if (!empty($id)) {
        $sql = "SELECT nom_article, nom, prenom, v.quantite, prix, date_vente, v.id, prix_unitaire, adresse, telephone
                FROM client AS c, vente AS v, article AS a 
                WHERE v.id_article = a.id AND v.id_client = c.id AND v.id = ? AND etat = ?";
        $req = $GLOBALS['connexion']->prepare($sql);
        $req->execute(array($id, 1));
        return $req->fetch();
    } else {
        $sql = "SELECT nom_article, nom, prenom, v.quantite, prix, date_vente, v.id, prix_unitaire, adresse, telephone, a.id AS id_article
                FROM client AS c, vente AS v, article AS a 
                WHERE v.id_article = a.id AND v.id_client = c.id AND etat = ?";
        $req = $GLOBALS['connexion']->prepare($sql);
        $req->execute(array(1));
        return $req->fetchAll();
    }
}

function getAllVentes() {
    $sql = "SELECT v.date_vente, c.nom, c.prenom, a.nom_article, v.prix
            FROM vente AS v
            JOIN client AS c ON v.id_client = c.id
            JOIN article AS a ON v.id_article = a.id
            WHERE v.etat = 1"; // Assurez-vous de filtrer par l'état si nécessaire
    $req = $GLOBALS['connexion']->prepare($sql);
    $req->execute();
    return $req->fetchAll();
}









function getFournisseur($id=null)
{
    if (!empty($id)) {
        $sql = "SELECT * FROM fournisseur WHERE id=?";
                
        $req = $GLOBALS['connexion']->prepare($sql);
            
        $req->execute(array($id));

        return $req->fetch();
    } else {
        $sql = "SELECT * FROM fournisseur";
                
        $req = $GLOBALS['connexion']->prepare($sql);
                
        $req->execute();
    
        return $req->fetchAll();
    } 
}

function getCommande($id = null)
{
    $sql = "SELECT nom_article, nom, prenom, co.quantite, prix, date_commande, co.id, prix_unitaire, adresse, telephone
            FROM fournisseur AS f
            JOIN commande AS co ON co.id_fournisseur = f.id
            JOIN article AS a ON co.id_article = a.id";
    
    if (!empty($id)) {
        $sql .= " WHERE co.id = ?";
        $req = $GLOBALS['connexion']->prepare($sql);
        $req->execute(array($id));
        return $req->fetch();
    } else {
        $req = $GLOBALS['connexion']->prepare($sql);
        $req->execute();
        return $req->fetchAll();
    }
}

function getallCommande()
{
    $sql = "SELECT COUNT(*) AS nbre FROM commande ";

    $req = $GLOBALS['connexion']->prepare ($sql);
    $req->execute();
    return $req->fetch();
}

function getallVente()
{
    $sql = "SELECT COUNT(*) AS nbre FROM vente ";

    $req = $GLOBALS['connexion']->prepare ($sql);
    $req->execute();
    return $req->fetch();
}

function getallArticle()
{
    $sql = "SELECT COUNT(*) AS nbre FROM article ";

    $req = $GLOBALS['connexion']->prepare ($sql);
    $req->execute();
    return $req->fetch();
}

function getallCa()
{
    $sql = "SELECT SUM(prix) AS prix FROM vente ";

    $req = $GLOBALS['connexion']->prepare ($sql);
    $req->execute();
    return $req->fetch();
}

function getlastVente()
{
    // Assuming $GLOBALS['connexion'] is your database connection object
    $sql = "SELECT nom_article, nom, prenom, v.quantite, prix, date_vente, v.id, prix_unitaire, adresse, telephone
            FROM client AS c
            JOIN vente AS v ON v.id_client = c.id
            JOIN article AS a ON v.id_article = a.id
            ORDER BY date_vente DESC
            LIMIT 10";
    
    $req = $GLOBALS['connexion']->prepare($sql);
    $req->execute();
    return $req->fetchAll(); // Use fetchAll() to get all rows of result set
}

function getMostvente()
{
    $sql = "SELECT nom_article, SUM(prix) AS prix
            FROM client AS c
            JOIN vente AS v ON v.id_client = c.id
            JOIN article AS a ON v.id_article = a.id
            GROUP BY v.id 
            ORDER BY SUM(prix) DESC LIMIT 10";
    
    $req = $GLOBALS['connexion']->prepare($sql);
    $req->execute();
    return $req->fetchAll(); // Use fetchAll() to get all rows of result set
}







 




