<?php
session_start();

// Vérifier si l'utilisateur est déjà connecté
if(isset($_SESSION['nom_utilisateur'])) {
    // Message de confirmation
    $_SESSION['notification'] = "Vous avez été déconnecté avec succès.";
    
    // Détruire toutes les données de session
    session_destroy();
    
    // Redémarrer la session pour afficher le message de notification
    session_start();
    $_SESSION['notification'] = "Vous avez été déconnecté avec succès.";
    
    // Rediriger vers la page de connexion
    header("Location: login.php");
    exit();
} else {
    // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    header("Location: login.php");
    exit();
}
?>
