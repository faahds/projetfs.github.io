<?php
session_start();
include 'connexion.php';

if (!empty($_POST['id_article']) && !empty($_POST['id_fournisseur']) && !empty($_POST['quantite']) && !empty($_POST['prix'])) {
    // Étape 1 : Insérer la commande dans la table 'commande'
    $sql = "INSERT INTO `commande` (id_article, id_fournisseur, quantite, prix) VALUES (?, ?, ?, ?)";
    $req = $connexion->prepare($sql); 
    $req->execute(array(
        $_POST['id_article'],
        $_POST['id_fournisseur'],
        $_POST['quantite'], 
        $_POST['prix']
    ));

    if ($req->rowCount() != 0) {
        // Étape 2 : Récupérer la quantité actuelle de l'article
        $sql = "SELECT quantite FROM article WHERE id = ?";
        $req = $connexion->prepare($sql); 
        $req->execute(array($_POST['id_article']));
        $article = $req->fetch();

        if ($article) {
            // Étape 3 : Ajouter la nouvelle quantité à la quantité actuelle
            $nouvelle_quantite = $article['quantite'] + $_POST['quantite'];

            // Étape 4 : Mettre à jour la quantité de l'article dans la table 'article'
            $sql = "UPDATE article SET quantite = ? WHERE id = ?";
            $req = $connexion->prepare($sql); 
            $req->execute(array($nouvelle_quantite, $_POST['id_article']));

            if ($req->rowCount() != 0) {
                $_SESSION['message']['text'] = "Votre commande a été effectuée avec succès.";
                $_SESSION['message']['type'] = "success";
            } else {
                $_SESSION['message']['text'] = "Impossible de mettre à jour la quantité de l'article.";
                $_SESSION['message']['type'] = "danger";
            }
        } else {
            $_SESSION['message']['text'] = "L'article spécifié est introuvable.";
            $_SESSION['message']['type'] = "danger";
        }
    } else {
        $_SESSION['message']['text'] = "Une erreur s'est produite lors de l'insertion de la commande.";
        $_SESSION['message']['type'] = "danger";
    }
} else {
    $_SESSION['message']['text'] = "Une information obligatoire n'a pas été renseignée.";
    $_SESSION['message']['type'] = "danger";
}

header('Location: commande.php');
exit();
?>
