<?php
include_once 'function.php';

?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <title>Gestion de stock</title>
    <link rel="stylesheet" href="style.css" />
    <link
      href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css"
      rel="stylesheet"
    />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>
  <body>
    <div class="sidebar">
    
      <div class="logo-details"> 
        <span class="logo_name"><img src="" alt="" srcset=""></span>
      </div>
      
      <ul class="nav-links">

        <li>
          <a href="dashboard.php" class="active">
            <i class="bx bx-grid-alt"></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>

        <li>
          <a href="vente.php">
          <i class='bx bx-shopping-bag'></i>
            <span class="links_name">Vente</span>
          </a>
        </li>

        <li>
          <a href="client.php">
            <i class="bx bx-user"></i>
            <span class="links_name">Client</span>
          </a>
        </li>


        <li>
          <a href="article.php">
            <i class="bx bx-box"></i>
            <span class="links_name">Produit</span>
          </a>
        </li>
          
      <li>
        <a href="fournisseur.php">
          <i class="bx bx-coin-stack"></i>
            <span class="links_name">fournisseur</span>
          </a>
        </li>

        <li>
        <a href="commande.php">
          <i class="bx bx-coin-stack"></i>
            <span class="links_name">Commandes</span>
          </a>
        </li>



        <li class="log_out">
          <a href="logout.php">
            <i class="bx bx-log-out"></i>
            <span class="links_name">Déconnexion</span>
          </a>
        </li>
      </ul>

      
    </div>
    <section class="home-section">
      <nav>
        <div class="sidebar-button">
          <i class="bx bx-menu sidebarBtn"></i>
          <span class="dashboard">Dashboard</span>
        </div>
        <div class="search-box">
          <input type="text" placeholder="Recherche..." />
          <i class="bx bx-search"></i>
        </div>
      </nav>